import inspect
from abc import ABC

def truefalse(bool_str: str):
    return bool_str == 'True'

class Virus(ABC):
    def __init__(self, name: str, source: str, protectionlevel: int):
        self.__name = name
        self.source = source
        self.protectionlevel = int(protectionlevel)

    def get_type(self):
        raise NotImplementedError(
            "Error")

    def __str__(self):
        return ','.join([self.get_type(), *map(str, self.__dict__.values())])

    def deserialize(device_str: str):
        str_parts = device_str.split(',')
        if str_parts[0] == 'Hiding':
            return Masker(str_parts[1], str_parts[2], int(str_parts[3]), truefalse(str_parts[4]), str_parts[5])
        else:
            return Worm(str_parts[1], str_parts[2], int(str_parts[3]), int(str_parts[4]), truefalse(str_parts[5]), str_parts[6])

    @property
    def name(self):
        return self.__name

    @property
    def source(self):
        return self.__source

    @source.setter
    def source(self, source: str):
        source_LIST = ['FleshDrive', 'Internet', 'Program','LocalNetwork']
        if source in source_LIST:
            self.__source = source
        else:
            raise ValueError('Way of getting a virus '+' '.join(source_LIST))

    @property
    def protectionlevel(self):
        return self.__protectionlevel

    @protectionlevel.setter
    def protectionlevel(self, protectionlevel: int):
        if protectionlevel <= 1:
            raise ValueError("Min protection level <= 1")
        if protectionlevel > 5:
            raise ValueError(
                "protection level > 5")
        self.__protectionlevel = protectionlevel

class Masker(Virus):
    def __init__(self, name: str, source: str, protectionlevel: int, availability: bool, role1: str):
        super().__init__(name, source, protectionlevel)
        self.__availability = availability
        self.__role1 = role1

    def get_type(self):
        return "Hiding"

    @ property
    def availability(self):
        return self.__availability

    @ property
    def role1(self):
        return self.__role1

class Worm(Virus):
    def __init__(self, name: str, source: str, protectionlevel: int, affectedzones: int, athreat: bool, whatattacks: str):
        super().__init__(name, source, protectionlevel)
        self.affectedzones = int(affectedzones)
        self.__athreat = athreat
        self.__whatattacks = whatattacks

    def get_type(self):
        return "Spyware"

    @ property
    def affectedzones(self):
        return self.__affectedzones

    @affectedzones.setter
    def affectedzones(self, affectedzones: int):
        if affectedzones < 1:
            raise ValueError("Min affected zones 1")
        if affectedzones > 10:
            raise ValueError(
                "Max affected zones 10")
        self.__affectedzones = affectedzones

    @ property
    def athreat(self):
        return self.__athreat

    @ property
    def whatattacks(self):
        return self.__whatattacks

def save():
    with open('database.txt', 'w', encoding="utf-8") as db_file:
        db_file.write('\n'.join(map(str, db)))

def find_entry(name: str):
    for e in db:
        if e.name == name:
            return e
    return None

def addviruses(e: Virus):
    if find_entry(e.name) is None:
        db.append(e)
        save()
    else:
        raise ValueError(f"An entry with the same name already exists in the database")

def removeviruses(name: str):
    e = find_entry(name)
    if e is not None:
        db.remove(e)
        save()
    else:
        raise ValueError(f"An entry with this name was not found in the database")

def parse():
    db = []
    with open('database.txt', 'r', encoding="utf-8") as database:
        for line in database.readlines():
             if len(line) > 0:
                db.append(Virus.deserialize(line.strip("\r\n ")))
        return db

db = parse()

def bool_to_ru(e):
    if type(e) == bool:
        return 'yes' if e else 'no'
    return e


while True:
    command = None
    parseRu = {
        "name": "name virus",
        "source": "Source",
        "protectionlevel": "Protection level",
        "availability": "Availability",
        "role1": "Role",
        "affectedzones": "Affected zones",
        "athreat": "The presence of a threat",
        "whatattacks": "What attacks"
    }
    while command not in ['find', 'add', 'del']:
        command = input("enter command(find, add, del): ")
    if command == 'find':
        e = find_entry(input('name virus: '))
        if e is not None:
            for key in e.__dict__:
                print(
                    f"{parseRu[key.split('__')[1]]}: {bool_to_ru(e.__dict__[key])}")
        else:
            print(f"virus no exist")
    elif command == 'add':
        try:
            dclass = None
            while dclass not in ['masker', 'worm']:
                dclass = input(
                    "type of virus(masker, worm): ").lower()
            if dclass == "masker":
                values = []
                for key in list(inspect.signature(Masker.__init__).parameters)[1:]:
                    values.append(input(f"{parseRu[key]}: "))
                for i in range(len(values)):
                    if values[i].lower() == 'yes':
                        values[i] = True
                    elif values[i].lower() == 'no':
                        values[i] = False
                addviruses(Masker(*values))
            else:
                values = []
                for key in list(inspect.signature(Worm.__init__).parameters)[1:]:
                    values.append(input(f"{parseRu[key]}: "))
                for i in range(len(values)):
                    if values[i].lower() == 'yes':
                        values[i] = True
                    elif values[i].lower() == 'no':
                        values[i] = False
                addviruses(Worm(*values))
        except ValueError as e:
            print(e)
    else:
        try:
            removeviruses(input('name virus: '))
        except ValueError as e:
            print(e)