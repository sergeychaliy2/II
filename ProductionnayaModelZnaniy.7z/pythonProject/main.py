import interp
def rule_repr(rule):
    mas1 = []
    for attr, values in rule['LHS'].items():
        mas1.append(attr + " = " + "|".join(values))
    (RHSkey, RHSvalue) = list(rule['RHS'].items())[0]
    return "IF " + " & ".join(mas1) + " THEN " + RHSkey + " = " + RHSvalue

def PrintStatusPC():
    print("Статус вашего пк :")
    for r, v in mas.items():
        print(r, " = ", v)

#  RETURN LIST RULES
def getConflictRules(rules, goal):
    ruleset = []
    for rule in rules:
        attribute = list(rule['RHS'].keys())[0]
        if attribute == goal:
            ruleset.append(rule)
    return ruleset
# checking the need to go further
def conflictRuleExists(rules, goal):
    for rule in rules:
        attribute = list(rule['RHS'].keys())[0]
        if attribute == goal:
            return True
    return False

# validation rules
def ruleWorks(rule, mas):
    conditions = rule['LHS']

    for param in conditions:
        if param in mas:
            if mas[param] not in conditions[param]:
                return False
        else:
            return False
    return True
#INPUT
def parameterInput(parameterinput1, mas):
    value = input("произведите оценку '" + parameterinput1 +
                  "' " + str(parameters[parameterinput1+"*"]) + ": ")
    while(value not in parameters[parameterinput1+"*"]):
        value = input()
    mas[parameterinput1] = value

def knowledge_base_output(parameters, rules):
    print("возможные значения:")
    for attr, value in parameters.items():
        print(attr + " = " + " | ".join(value))
    print("\n правила:")
    for i, rule in enumerate(rules):
        print(str(i+1) + ") " + rule_repr(rule))

parameters, rules = interp.parse('./globalBase.txt')
knowledge_base_output(parameters, rules)
mas = {}
goals = []
checked_goals = []
goals.append('у_вас')

while(True):
    if len(goals) == 0:
        break
    new_goal = False
    new_parameter = False
    goal = goals[-1]
    conflictRules = getConflictRules(rules, goal)
    remainingRules = len(conflictRules)
    for cr in conflictRules:
        if ruleWorks(cr, mas):
            (RHSkey, RHSvalue) = list(cr['RHS'].items())[0]
            mas[RHSkey] = RHSvalue
            curr_goal = goals.pop()
            new_goal = True
            PrintStatusPC()
            break

    if new_goal:
        continue
    # for each rule in the conflict rule set
    for cr in conflictRules:
        if new_goal:
            break
        remainingRules -= 1
        conditions = cr['LHS']
        # for each parameter of checked rules
        for parameterinput1 in conditions:
            if parameterinput1 in checked_goals:
                break
            if parameterinput1 in mas:
                if mas[parameterinput1] not in conditions[parameterinput1]:
                    break
            else:
                if conflictRuleExists(rules, parameterinput1) and parameterinput1 not in goals:
                    goals.append(parameterinput1)
                    new_goal = True
                    break
                elif parameterinput1 + "*" in parameters:
                    parameterInput(parameterinput1, mas)
                    new_parameter = True
                    break
                else:
                    checked_goals.append(parameterinput1)
        if new_parameter:
            break
        if remainingRules == 0 and not new_goal:
            curr_goal = goals.pop()
            checked_goals.append(curr_goal)
            print('В базе нет нужной информации о данном вирусе')
            break