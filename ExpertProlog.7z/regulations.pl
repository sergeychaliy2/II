:- dynamic xpositive/2, xnegative/2.

/* UI system */
main:-
	do_expert_job.

do_expert_job:-
      do_consulting.

do_consulting:-
      virus_is(X),!,
      format("Possible virus based on the performance of your PC: ~a.~n",[X]),
      clear.

do_consulting:-
      write("Information about the virus you are interested in in the BR."),nl,
      clear.

ask(X,Y):-
      format("Question : ~a ~a?~n",[X,Y]),
      write("1 - yes,"),nl,
      write("2 - no"),nl,
      readloop(Reply),
      remember(X,Y,Reply).

/* Input Validation */

readloop(Response):-
      read_string(user_input, "\n", "\r",_,Str),
      atom_number(Str, Response),
      legal_response(Response),!.

      legal_response(Response):-Response=1.
      legal_response(Response):-Response=2.

/* Mechanism for the conclusion of an expert opinion */

positive(X,Y):-
      xpositive(X,Y),!.

positive(X,Y):-
      not(getnegative(X,Y)),!,ask(X,Y).

getpositive(X,Y):-
       xpositive(X,Y),!.

getnegative(X,Y):-
      xnegative(X,Y),!.

negative(X,Y):-
      xnegative(X,Y),!.
negative(X,Y):-
       not(getpositive(X,Y)),!,not(ask(X,Y)).

remember(X,Y,1):-!,
      assertz(xpositive(X,Y)).

remember(X,Y,2):-!,
      assertz(xnegative(X,Y)),fail.

/* Production rules */

     virus_is("Trojan"):-
           it_is("malicious"),
           positive("performance","Fast"),
           positive("manifestation","After reboot"),
           positive("performance","lags"),
           positive("performance","pc is buzzing"),
           positive("performance","normal operation"),
           positive("processor load","40"),
           positive("performance","graphics card load"),!.


     virus_is("virus_chernoblya"):-
           it_is("dangerous"),
           positive("performance","Slow"),
           positive("manifestation","After testing"),
           positive("performance","lags"),
           positive("performance","system damage"),
           positive("performance","work_in_regular_mode"),
           positive("processor load","50"),
           positive("performance","graphics card load"),!.

     virus_is("Spyware"):-
           it_is("insignificant"),
           positive("performance","Average"),
           positive("manifestation","After switching on"),
           positive("performance","lags"),
           positive("performance","system damage"),
           positive("performance","work_in_regular_mode"),
           positive("processor load","45"),
           positive("performance","graphics card load"),!.

     virus_is("Adware"):-
           it_is("stealing"),
           positive("performance","Fast"),
           positive("manifestation","After Notifications"),
           positive("performance","without lags"),
           positive("performance","system damage"),
           positive("performance","work_in_regular_mode"),
           positive("processor load","60"),
           positive("performance","graphics card load"),!.

     virus_is("Winlock"):-
           it_is("informing"),
           positive("performance","Average"),
           positive("manifestation","After reboot"),
           positive("performance","lags"),
           positive("performance","system damage"),
           positive("performance","work_in_regular_mode"),
           positive("processor load","65"),
           positive("performance","graphics card load"),!.

     virus_is("Zombie"):-
           it_is("informing"),
           positive("performance","Slow"),
           positive("manifestation","After load"),
           positive("performance","without lags"),
           positive("performance","system damage"),
           positive("performance","work_in_regular_mode"),
           positive("processor load","70"),
           positive("performance","graphics card load"),!.

     virus_is("Nimda"):-
           it_is("consuming"),
           positive("performance","Very slow"),
           positive("manifestation","After games"),
           positive("performance","lags"),
           positive("performance","system damage"),
           positive("performance","work_in_regular_mode"),
           positive("processor load","75"),
           positive("performance","graphics card load"),!.

     it_is("malicious"):-
           positive("the virus has","malicious"),!.

     it_is("dangerous"):-
           positive("the virus has","dangerous"),!.

/* Destroy all yes and no responses in the database */

   clear:-retract(xpositive(_,_)),retract(xnegative(_,_)),fail,!.
   clear.

%:- do_expert_job.
