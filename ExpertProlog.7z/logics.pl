:- dynamic yes/1, no/1.
/* db. */

/* Placement in the resident database of information from the statements of the KB ES */

     assert_database:-
           rule(Rule_number,Category,Type_of_breed,Conditions),
           assertz(d_rule(Rule_number,Category,Type_of_breed,Conditions)),fail.

     assert_database:-
           cond(Cond_number,Condition),
           assertz(d_cond(Cond_number,Condition)),fail.

     assert_database:-!.

/* Conditions-characteristics of various viruses.*/
   
     cond(1,"overwhelming virus").
     cond(2,"withdrawing virus").
     cond(3,"steals information").
     cond(4,"loads the processor").
     cond(5,"overclocks the video card").
     cond(6,"replaces data").
     cond(7,"opens windows").
     cond(8,"destroys data").
    
/* Virus type data */

     topic("overwhelming").
     topic("withdrawing").

/* Data on specific viruses */

     rule(1,"virus","overwhelming",[1]).
     rule(2,"virus","withdrawing",[2]).
     rule(3,"overwhelming","Trojan",[3,5,7]).
     rule(4,"overwhelming","Virus_chernoblya",[3,6,7]).
     rule(5,"overwhelming","Spyware",[5,6,7,8]).
     rule(6,"overwhelming","Adware",[4,6,7]).
     rule(7,"withdrawing","Winlock",[3,5,6,7]).
     rule(8,"withdrawing","Zombie",[4,6]).
     rule(9,"withdrawing","Nimda",[4,5,7]).
     rule(10,"withdrawing","Rootkit",[5,7,8]).
   
/* UI system */

main:-
   assert_database,
   do_expert_job.

do_expert_job:-
    do_consulting,
    clear.

do_consulting:-
   go([],"virus"),!.

do_consulting:-
   write("Information about the virus you are interested in is not in the KB."), nl,
   clear.

/* Issuing a hint */

info:-
   write("The knowledge base contains information about PC viruses: "), nl,
   topic(X), format('\t~w~n',[X]).

/* Requesting and receiving yes and no responses from the user */

ask_question(Breed_cond,Text):-
   format("Вопрос : ~a?~n",[Text]),
   write("1 - yes,"),nl,
   write("2 - no"),nl,
   readloop(Response),
   do_answer(Breed_cond,Response).

/* Input Validation */

readloop(Response):-
   read_string(user_input, "\n", "\r",_,Str),
   atom_number(Str, Response),
   legal_response(Response),!.

legal_response(Response):-Response=1.
legal_response(Response):-Response=2.

/* Membership of an element in a list */

member(Head,[Head|_]):-!.
member(Elem,[_|T]):-
     member(Elem,T).

/* withdrawal mechanism */

/* Inference engine start rule */

go(_,Mygoal):-
   not(rule(_,Mygoal,_,_)),!,
   format("possible virus: ~a.~n",[Mygoal]).

go(History,Mygoal):-
   rule(Rule_number,Mygoal,Type_of_breed,Conditions),
   check(Rule_number,History,Conditions),
   go([Rule_number|History],Type_of_breed).

/* Mapping User Inputs to Attribute Lists
   viruses */

check(Rule_number,History,[Breed_cond|Rest_breed_cond_list]):-
   yes(Breed_cond),!,
   check(Rule_number,History,Rest_breed_cond_list).

check(_,_,[Breed_cond|_]):-
   no(Breed_cond),!,fail.

check(Rule_number,History,[Breed_cond|Rest_breed_cond_list]):-
   cond(Breed_cond,Text),
   ask_question(Breed_cond,Text),
   check(Rule_number,History,Rest_breed_cond_list).

check(_,_,[]).

do_answer(Cond_number,1):-!,
   assertz(yes(Cond_number)).

do_answer(Cond_number,2):-!,
   assertz(no(Cond_number)),fail.
   
/* Destroy all yes and no responses in the database */

clear:-retract(yes(_)),retract(no(_)),retract(goes(_,_)),fail,!.
clear.

%:- main.